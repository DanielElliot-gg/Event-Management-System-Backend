package com.eventmanagement.dto;

public class planner_task {
	private String taskId;
    private int staffId;
    
	public planner_task() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public int getStaffId() {
		return staffId;
	}
	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
    
    
}
